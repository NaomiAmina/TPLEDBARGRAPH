#include "stm32f10x.h"


// Le programme du sc�nario de 1-1
void TimeFunction(int Temps);
int i,j,k, value;
int main(void)
{
    RCC->APB2ENR |= 0x00000008;
    GPIOB->CRL = (GPIOB->CRL & 0x0000FFF0) | 0x33330004;
    GPIOB->CRH = 0x33333333;
    GPIOB->BSRR = 0xFFF00000;
    while(1)
    {
        i = GPIOB->IDR & 0x00000001;
        if (i == 0x00000001)  
        {
            for (j=0; j<8; j++)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<j & 0x0000FF00;
                value |= 1<<(6+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }					
						 for (j=9; j>=0; j--)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<(j + 16) & 0x0000FF00;
                value |= 1<<(6+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }					
        }
    }
		
}

void TimeFunction(int Temps)
{
    int j,k;
    for (j=0;j<Temps;j++)
    {
        for (k=0;k<2882;k++)
        {
        }
    }
}






// Le programme du sc�nario de 2-2

/*#include "stm32f10x.h"
void TimeFunction(int Temps);
int i,j,k, value;
int main(void)
{
    RCC->APB2ENR |= 0x00000008;
    GPIOB->CRL = (GPIOB->CRL & 0x0000FFF0) | 0x33330004;
    GPIOB->CRH = 0x33333333;
    GPIOB->BSRR = 0xFFF00000;
    while(1)
    {
        i = GPIOB->IDR & 0x00000001;
        if (i == 0x00000001)  
        {
            for (j=0; j<8; j++)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<j & 0x0000FF00;
                value |= 1<<(5+j)| 1<<(6+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }					
						 for (j=9; j>=0; j--)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<(j + 16) & 0x0000FF00;
                value |= 1<<(8+j)| 1<<(9+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }					
        }
    }
		
}

void TimeFunction(int Temps)
{
    int j,k;
    for (j=0;j<Temps;j++)
    {
        for (k=0;k<2882;k++)
        {
        }
    }
}*/



// le programe du sc�narion5-5

/*#include "stm32f10x.h"
void TimeFunction(int Temps);
int i,j,k,m, value;
int main(void)
{
    RCC->APB2ENR |= 0x00000008;
    GPIOB->CRL = (GPIOB->CRL & 0x0000FFF0) | 0x33330004;
    GPIOB->CRH = 0x33333333;
    GPIOB->BSRR = 0xFFF00000;
    while(1)
    {
        i = GPIOB->IDR & 0x00000001;
        if (i == 0x00000001)  
        {
            for (j=0; j<8; j++)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<j & 0x0000FF00;
							     for (m=9; m>=4; m--)
							{  
								value |= 1 <<(m+j) ;
							}
                value |= 1<<(6+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }	
						
						 for (j=9; j>=0; j--)
            {
                GPIOB->BRR = 0x0000FFFF;
                value = 1<<(j + 16) & 0x0000FF00;
							     for (m=9; m>=4; m--)
							{  
								value |= 1 <<(m+j) ;
							}
                value |= 1<<(6+j);
                GPIOB->BSRR = value;
                TimeFunction(3);
                GPIOB->BRR = value;
            }					
        }
    }
		
}

void TimeFunction(int Temps)
{
    int j,k;
    for (j=0;j<Temps;j++)
    {
        for (k=0;k<2882;k++)
        {
        }
    }
	}*/